# 1 . Retrive the total number of orders placed . 
Select count(order_id) as total_orders From orders ;


